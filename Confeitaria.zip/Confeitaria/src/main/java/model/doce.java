/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Raquel
 */
public class doce {
    
private int id_doce;
private String nome_doce;
private String categoria;
private float preco;
private String descricao;

// Getters e Setters
public int getId() {
return id_doce;
}
public void setId(int id_doce) {
this.id_doce = id_doce;
}
public String getnomedoce() {
return nome_doce;
}
public void setnomedoce(String nome_doce) {
this.nome_doce = nome_doce;
}
public String getcategoria() {
return categoria;
}
public void setcategoria(String categoria) {
this.categoria = categoria;
}
public float getpreco() {
return preco;
}
public void setpreco(float preco) {
this.preco = preco;
}
public String getdesc(){
    return descricao;
}
public void setdesc(String descricao){
    this.descricao = descricao;
}
    
}
